<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dbgogjzxrgtofw' );

/** Database username */
define( 'DB_USER', 'uxkndeggneefx' );

/** Database password */
define( 'DB_PASSWORD', '5ttt2zejbqf7' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '&L(vFgrA;{NX7r|54Cf##fdN8esg+OO9_wDfhA~6-Z&z?PEu[3iyAjVs.~_au0;h' );
define( 'SECURE_AUTH_KEY',   ' z>fXc&Jjn24EPt_ujcZI[W?c6XtNCEU-+$/}x5rygInC9T`Y!2(494|*U)X21Cg' );
define( 'LOGGED_IN_KEY',     '6pm_*0%y1bhc)(Jl[/6fI@d%+MFWhM4FH#t+R!e$-nssR!Z~V+GQa7HaVT~=GR7 ' );
define( 'NONCE_KEY',         'C}w f7 T|lJN3=C<F@iO0[cAfz:8SURq3Cxm/334wjCjNsVBxp(agg@l}2&;EDvI' );
define( 'AUTH_SALT',         '0R:5QX4idpdw1Syt(l$MXd[3M=^P_wGOXT:5etH]q{v.3QWFaa)w6]]t@~ImANQ;' );
define( 'SECURE_AUTH_SALT',  '%yjP7q8W:]L{i2b!j.P}r%m[*$@?ADnB6g<s(07*{yXf~77yYsJ|j h)~Nyp0p?C' );
define( 'LOGGED_IN_SALT',    'c(Hn%mI[s?YUG2E(14BE7s6G8zD.q!zK?Gwv]?Y/XuZ-v4m?>1Q+W#+tGp$Sa3LU' );
define( 'NONCE_SALT',        '~NqTOFm2s6%N+q.1-1OfkjtEo3}Vf6/cGXjgrLK>{Gyx0;MJZvRzi5L(_Cyt=]rZ' );
define( 'WP_CACHE_KEY_SALT', ';8-.yuW,Is W*edBU*=}Z%xWr%7yrgDeU1&:{:av!lmG;mkl6G!Cj)A%F()I_qu%' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
@include_once('/var/lib/sec/wp-settings.php'); // Added by SiteGround WordPress management system
